<h1>Pagina teste</h1>

<p>
	Repare no HTML que ela chama um CSS teste, que na verdade nem existe na pasta. 
	Diferente do metodo index que chama o CSS default.
</p>

<p>
	E aqui chamamos apenas a JQuery como JS e não o Home como no Default.
</p>

<p>
	Olhe para o Titulo da pagina e faça a mesma observação.
</p>