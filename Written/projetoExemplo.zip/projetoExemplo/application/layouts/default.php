<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>{title_for_layout}</title>
		
		{css_for_layout}
        	{js_for_layout}
		
	</head>
	<body>
		<div id="geral">
			
			<div id="topo">
				<ul id="menu">
					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
				</ul>
			</div>
			
			
			<div id="meio">
			
				{content_for_layout}
			
			</div>
			
			<br style="clear: both;" />
			
			<div id="rodape">
				<p class="rodape">
					Todos os direitos reservados - Bla Bla Bla
				</p>
			</div>
		
		</div>
	</body>
</html>