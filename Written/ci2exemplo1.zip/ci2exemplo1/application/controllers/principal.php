<?php

    /**
     *
     */
    class Principal extends CI_Controller
    {

    /**
    * Layout default utilizado pelo controlador.
    */
    public $layout = 'default';

    /**
    * Titulo default.
    */
    public $title = '::: Titulo default :::';

    /**
    * Definindo os css default.
    */
    public $css = array('default');

    /**
    * Carregando os js default.
    */
    public $js = array('home');

    // Metodoo index
    function index()
    {
        // Carregando a view.
        $this->load->view('home');
    }

    // Metodo teste
    function teste()
    {
        //Title
        $this->title = '::: TESTE Titulo :::';

        //CSS
        $this->css = array('teste', 'default');

        //JS
        $this->js = array('jquery');

        // Carregando a View
        $this->load->view('teste');
    }

}